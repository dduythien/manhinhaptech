{
	"icons": [
		"puzzle",
		"trust",
		"target",
		"digital-strategy",
		"management",
		"sms",
		"live",
		"email",
		"star",
		"research"
		]
}