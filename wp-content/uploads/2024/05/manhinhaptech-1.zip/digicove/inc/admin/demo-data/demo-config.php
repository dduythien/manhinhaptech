<?php
$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'digicove' => array(
		'title'       => 'Digicove',	
		'description' => '',
		'screenshot'  => $uri . 'digicove.jpg',
		'preview'     => 'https://demo.bravisthemes.com/digicove/',
	),	
);