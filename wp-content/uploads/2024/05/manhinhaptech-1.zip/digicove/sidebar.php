<?php
/**
 * @package Bravisthemes
 */

dynamic_sidebar( digicove()->get_sidebar() );